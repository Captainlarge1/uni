#include "environment.h"
#include "simulator.h"
#include "utilities.h"
#include "evaluator.h"
#include "list.h"

void environment_start(unsigned int thread_count,
		       unsigned int iterations,
		       unsigned int batch_size) {
}

void environment_stop() {
}
