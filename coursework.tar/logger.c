#include "logger.h"
#include "utilities.h"

void logger_start() {
}

void logger_stop() {
}

void logger_write(char const* message) {
}
