#include "event_source.h"
#include "utilities.h"
#include "simulator.h"

void event_source_start(useconds_t interval) {
}

void event_source_stop() {
}

